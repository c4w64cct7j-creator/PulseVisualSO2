package com.example.pulsevisual;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.*;
import android.text.InputType;

public class MainActivity extends Activity {
    int bg = Color.rgb(9,11,18), panel = Color.rgb(19,22,34), purple = Color.rgb(183,92,255);
    int accent = Color.rgb(183,92,255);
    LinearLayout root, content;
    TextView status;
    String current = "Главная";

    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }

    GradientDrawable shape(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }

    LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }

    void pad(View v, int all) { v.setPadding(dp(all),dp(all),dp(all),dp(all)); }

    TextView button(String label, Runnable action) {
        TextView b = text(label, 14, Color.WHITE, true); b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12),dp(12),dp(12),dp(12)); b.setBackground(shape(panel,14,accent));
        b.setOnClickListener(v -> action.run()); return b;
    }

    void addSpace(LinearLayout parent, int h) {
        View v = new View(this); parent.addView(v, new LinearLayout.LayoutParams(1,dp(h)));
    }

    void card(LinearLayout parent, String title, String subtitle, View extra) {
        LinearLayout box = column(); pad(box,14); box.setBackground(shape(panel,18,Color.rgb(40,43,60)));
        TextView h = text(title,16,Color.WHITE,true); box.addView(h);
        if (subtitle != null) { addSpace(box,4); TextView s=text(subtitle,12,Color.rgb(163,168,190),false); box.addView(s); }
        if (extra != null) { addSpace(box,10); box.addView(extra); }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(12);
        parent.addView(box,lp);
    }

    void showToast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildShell();
        showPage("Главная");
    }

    void buildShell() {
        root = column(); root.setBackgroundColor(bg);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout outer = column(); pad(outer,18);
        LinearLayout header = row();
        LinearLayout brand = column();
        TextView logo = text("PULSE  /  VISUAL",20,Color.WHITE,true);
        TextView sub = text("STANDOFF 2  •  COMPANION",10,accent,true);
        brand.addView(logo); brand.addView(sub);
        header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView dot = text("● LIVE UI",11,Color.rgb(103,235,174),true);
        header.addView(dot); outer.addView(header); addSpace(outer,18);

        LinearLayout nav = row(); nav.setPadding(0,0,0,dp(14));
        String[] tabs={"Главная","Прицел","Визуал","Настройки"};
        for (String tab:tabs) {
            TextView t=text(tab,11,Color.WHITE,true); t.setGravity(Gravity.CENTER);
            t.setPadding(dp(9),dp(11),dp(9),dp(11));
            t.setBackground(shape(tab.equals(current)?accent:panel,12,0));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(2),0,dp(2),0);
            nav.addView(t,lp);
            t.setOnClickListener(v -> { current=tab; rebuildNav(nav,tabs); showPage(tab); });
        }
        outer.addView(nav);
        content=column(); outer.addView(content);
        TextView footer=text("Локальный прототип • не подключается к игре",10,Color.rgb(120,125,148),false);
        footer.setGravity(Gravity.CENTER); pad(footer,12); outer.addView(footer);
        scroll.addView(outer); root.addView(scroll); setContentView(root);
    }

    void rebuildNav(LinearLayout nav,String[] tabs) {
        nav.removeAllViews();
        for(String tab:tabs) {
            TextView t=text(tab,11,Color.WHITE,true); t.setGravity(Gravity.CENTER); t.setPadding(dp(9),dp(11),dp(9),dp(11));
            t.setBackground(shape(tab.equals(current)?accent:panel,12,0));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(2),0,dp(2),0); nav.addView(t,lp);
            t.setOnClickListener(v->{current=tab;rebuildNav(nav,tabs);showPage(tab);});
        }
    }

    void showPage(String page) {
        content.removeAllViews();
        AlphaAnimation fade=new AlphaAnimation(0f,1f); fade.setDuration(220); content.startAnimation(fade);
        switch(page) {
            case "Прицел": aimPage(); break;
            case "Визуал": visualPage(); break;
            case "Настройки": settingsPage(); break;
            default: homePage();
        }
    }

    void title(LinearLayout p,String h,String sub) {
        TextView a=text(h,25,Color.WHITE,true); p.addView(a);
        TextView b=text(sub,13,Color.rgb(163,168,190),false); p.addView(b); addSpace(p,16);
    }

    void homePage() {
        title(content,"Играй в своём стиле","Настройки и визуальные пресеты для Standoff 2");
        LinearLayout hero=column(); pad(hero,18);
        hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(62,29,93),Color.rgb(25,28,48),Color.rgb(17,20,31)}));
        hero.setCornerRadius(dp(22));
        hero.addView(text("PULSE VISUAL",12,Color.rgb(223,179,255),true));
        addSpace(hero,8);
        hero.addView(text("Твой стиль.\nТвои настройки.",27,Color.WHITE,true));
        addSpace(hero,8);
        hero.addView(text("Настраивай прицел, темы и чувствительность в одном месте.",13,Color.rgb(215,213,230),false));
        addSpace(hero,16);
        hero.addView(button("Открыть настройки прицела",()->{current="Прицел";showPage(current);}));
        content.addView(hero); addSpace(content,14);
        card(content,"Быстрый профиль","Сохраняется только в рамках демонстрации",null);
        card(content,"Прицел","Цвет, размер и толщина линий",button("Настроить прицел",()->{current="Прицел";showPage(current);}));
        card(content,"Визуальные темы","Неоновые оттенки и эффекты интерфейса",button("Выбрать тему",()->{current="Визуал";showPage(current);}));
        card(content,"Важно","Приложение не читает память игры и не показывает реальные позиции игроков. ESP доступен только как безопасный макет.",null);
    }

    void aimPage() {
        title(content,"Настройка прицела","Предпросмотр и параметры для ручного переноса в игру");
        final int[] color={accent};
        final int[] size={18}, gap={7}, thick={3};
        TextView preview=text("+",52,color[0],true); preview.setGravity(Gravity.CENTER);
        LinearLayout pv=column(); pv.setGravity(Gravity.CENTER); pv.setMinimumHeight(dp(120));
        pv.setBackground(shape(Color.rgb(13,15,24),16,Color.rgb(45,48,68))); pv.addView(preview);
        card(content,"Предпросмотр", "Пример прицела — не накладывается поверх игры",pv);
        card(content,"Цвет прицела","Выбери цвет для предпросмотра",button("Фиолетовый",()->{color[0]=Color.rgb(183,92,255);preview.setTextColor(color[0]);}));
        LinearLayout colors=row();
        int[] colorsList={Color.rgb(183,92,255),Color.rgb(80,255,180),Color.rgb(255,90,110),Color.WHITE,Color.rgb(255,215,75)};
        String[] names={"Фиолетовый","Мятный","Красный","Белый","Жёлтый"};
        for(int i=0;i<colorsList.length;i++){ final int c=colorsList[i]; final String n=names[i]; TextView sw=button("●",()->{color[0]=c;preview.setTextColor(c);showToast("Цвет: "+n);}); sw.setTextColor(c); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);lp.setMargins(dp(2),0,dp(2),0);colors.addView(sw,lp);}
        card(content,"Палитра","Нажми на цвет",colors);
        addSliderCard("Размер",8,36,18,v->{size[0]=v;preview.setTextSize(v+28);});
        addSliderCard("Зазор",0,20,7,v->{gap[0]=v;});
        addSliderCard("Толщина",1,8,3,v->{thick[0]=v;});
        card(content,"Параметры","Размер: "+size[0]+" • зазор: "+gap[0]+" • толщина: "+thick[0],button("Показать выбранные значения",()->showToast("Размер "+size[0]+", зазор "+gap[0]+", толщина "+thick[0])));
    }

    interface IntChange { void changed(int v); }
    void addSliderCard(String label,int min,int max,int initial,IntChange change) {
        LinearLayout box=column(); TextView val=text(label+" · "+initial,14,Color.WHITE,true); box.addView(val);
        SeekBar seek=new SeekBar(this); seek.setMax(max-min); seek.setProgress(initial-min); seek.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean user){int v=p+min;val.setText(label+" · "+v);change.changed(v);}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        }); box.addView(seek); card(content,label,"Перемещай ползунок",box);
    }

    void visualPage() {
        title(content,"Визуал и эффекты","Темы меняют только интерфейс приложения");
        card(content,"Pulse Purple","Основная неоновая тема",button("Применить фиолетовую",()->setThemeColor(Color.rgb(183,92,255))));
        card(content,"Mint Neon","Свежий зелёно-мятный акцент",button("Применить мятную",()->setThemeColor(Color.rgb(65,240,177))));
        card(content,"Crimson","Красно-чёрная тема",button("Применить красную",()->setThemeColor(Color.rgb(255,76,104))));
        card(content,"Анимация интерфейса","Плавное появление экранов",button("Повторить анимацию",()->{AlphaAnimation a=new AlphaAnimation(0,1);a.setDuration(600);content.startAnimation(a);}));
        card(content,"ESP / подсветка","Демо-макет, не связанный с матчем и реальными игроками.",button("Открыть безопасный макет",()->showEspDemo()));
    }

    void showEspDemo() {
        content.removeAllViews(); title(content,"ESP · DEMO","Иллюстрация интерфейса, не игровой оверлей");
        LinearLayout arena=column(); arena.setMinimumHeight(dp(240)); pad(arena,12);
        arena.setBackground(shape(Color.rgb(13,20,24),18,Color.rgb(49,67,68)));
        arena.addView(text("TRAINING PREVIEW",11,Color.rgb(100,240,190),true));
        addSpace(arena,18);
        for(String s:new String[]{"┌──────────────┐\n│  PLAYER A   │\n│   DEMO      │\n└──────────────┘","┌──────────────┐\n│  PLAYER B   │\n│   DEMO      │\n└──────────────┘"}) {
            TextView t=text(s,15,Color.rgb(100,240,190),true);t.setGravity(Gravity.CENTER);t.setBackground(shape(Color.rgb(17,39,37),12,Color.rgb(65,220,170))); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(180),dp(74));lp.gravity=Gravity.CENTER;lp.bottomMargin=dp(10);arena.addView(t,lp);
        }
        card(content,"Только демонстрация","Макет не получает данные из Standoff 2 и не может выявлять игроков.",arena);
        content.addView(button("Назад к визуалу",()->{current="Визуал";showPage(current);}));
    }

    void setThemeColor(int c) {
        accent=c;
        showPage(current);
        showToast("Тема применена");
    }

    void settingsPage() {
        title(content,"Чувствительность","Справочные значения для ручной настройки в игре");
        addSliderCard("Общая чувствительность",1,100,55,v->{});
        addSliderCard("Чувствительность при прицеле",1,100,42,v->{});
        addSliderCard("Ускорение камеры",0,100,0,v->{});
        card(content,"Сохранение","В этом прототипе параметры не сохраняются после закрытия приложения. Их можно записать и перенести вручную.",button("Показать памятку",()->showToast("Запиши выбранные значения перед выходом.")));
        card(content,"О приложении","Pulse Visual SO2 · прототип 1.0\nНеофициальный companion-интерфейс. Не подключается к игре, не изменяет её файлы и не предоставляет преимущества в матче.",null);
    }
}
# Pulse Visual SO2 — Android prototype

A native Android Studio project for a standalone companion UI inspired by neon gaming dashboards.

## Features
- Dark neon UI with purple, mint, and crimson theme choices
- Aim/crosshair preview with color and size controls
- Sensitivity sliders as reference values
- Screen fade animations
- A clearly labelled ESP-style **offline mockup** only

## Important limitations
This is a standalone UI prototype. It does not inject into Standoff 2, read game memory, draw over the game, or reveal real player locations. The demo “ESP” screen is only a visual mockup. Settings are not persisted after closing the app yet.

## Build and run
1. Install Android Studio (stable version) and its Android SDK.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `PulseVisualSO2` folder.
4. Let Gradle sync. If prompted, install Android SDK Platform 35 and a compatible Android Gradle Plugin.
5. Connect an Android phone with USB debugging enabled, or create an emulator.
6. Press **Run ▶** for the `app` configuration.

## Build an APK
In Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
The debug APK is normally generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Tech
- Java
- Android SDK
- Min SDK 23 (Android 6.0)
- No third-party runtime dependencies
